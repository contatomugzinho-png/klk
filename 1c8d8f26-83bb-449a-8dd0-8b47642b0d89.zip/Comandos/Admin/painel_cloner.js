const { ApplicationCommandType, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const { owner } = require("../../config.json");

module.exports = {
  name: "painel_cloner",
  description: "[🤖] Envie o painel de clonagem.",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    // Verifica se é o dono do bot
    if (interaction.user.id !== owner) {
      return interaction.reply({
        content: "<:no:1409545199461597337> Você não tem permissão para usar este comando.",
        ephemeral: true,
      });
    } 

    try {
      // Responde à interação inicial para não dar erro de timeout
      await interaction.reply({
        content: "✅ Enviando o painel...",
        ephemeral: true,
      });

      const BotFoto = "https://cdn.discordapp.com/attachments/1445833065325658123/1451246813691772990/image.png";

      // Cria os botões corretamente
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('panel_cloner')
          .setLabel('Clonar Servidor')
          .setEmoji('1426559071233773621')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('clonersite')
          .setLabel('Clonar Site')
          .setEmoji('1426559071233773621')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('clonerfile')
          .setLabel('Clonar Arquivos')
          .setEmoji('1426559071233773621')
          .setStyle(ButtonStyle.Secondary)
      );

      const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel('Ajuda?')
          .setURL('https://discord.com/channels/1425820319238586412/1436475972814770298')
          .setEmoji('1425167713973702858')
          .setStyle(ButtonStyle.Link)
      );

      // Envia a mensagem no canal
      await interaction.channel.send({
        content: `**Cloud Store - Painel de Clonagem**\n\n> Olá Membro! Utilize os botões abaixo para acessar o painel de clonar de Servidor, Site & Arquivos.\n\n**COMO UTILIZAR & DICAS**\n\n> Para clonar um servidor será necessário:\n- ID Do Servidor que será Clonado\n- ID Do Servidor que será Copiado\n- Token de uma conta\n\n> Para clonar site apenas será necessário a URL do site.\n\n> Para clonar arquivos apenas será necessário o Token, ID do Canal e Webhook.`,
        components: [row, row2],
      });

    } catch (error) {
      console.error("Erro ao enviar painel:", error);
      if (!interaction.replied) {
        await interaction.reply({
          content: "❌ Ocorreu um erro ao enviar o painel.",
          ephemeral: true,
        });
      }
    }
  }, 
};
