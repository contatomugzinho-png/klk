const { ModalBuilder, TextInputStyle, TextInputBuilder, ActionRowBuilder, WebhookClient } = require("discord.js");
const { Client } = require('discord.js-selfbot-v13');

module.exports = {
    name: "interactionCreate",
    run: async (interaction) => {
        const { customId } = interaction;
        if (!customId) return;

        // --- BOTÃO CLONAR ARQUIVOS ---
        if (interaction.isButton() && customId === "clonerfile") {
            const modal = new ModalBuilder()
                .setCustomId('file-cloner-webhook-modal')
                .setTitle('Cloner Arquivos (Modo Estável)');

            const tokenInput = new TextInputBuilder()
                .setCustomId('token')
                .setLabel('Token da sua conta:')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Insira o token atualizado')
                .setRequired(true);

            const channelInput = new TextInputBuilder()
                .setCustomId('channel_id')
                .setLabel('ID do Canal de Origem:')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('ID do canal para clonar')
                .setRequired(true);

            const contentInput = new TextInputBuilder()
                .setCustomId('msg_content')
                .setLabel('Conteúdo da Mensagem:')
                .setStyle(TextInputStyle.Paragraph)
                .setPlaceholder('Texto que acompanhará cada arquivo')
                .setRequired(false);

            const webhookInput = new TextInputBuilder()
                .setCustomId('webhook_url')
                .setLabel('URL do Webhook de Destino:')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('https://discord.com/api/webhooks/...')
                .setRequired(true);

            modal.addComponents(
                new ActionRowBuilder().addComponents(tokenInput),
                new ActionRowBuilder().addComponents(channelInput),
                new ActionRowBuilder().addComponents(contentInput),
                new ActionRowBuilder().addComponents(webhookInput)
            );
            return await interaction.showModal(modal);
        }

        // --- SUBMIT DO MODAL ---
        if (interaction.isModalSubmit() && customId === "file-cloner-webhook-modal") {
            const token = interaction.fields.getTextInputValue('token').trim();
            const channelId = interaction.fields.getTextInputValue('channel_id').trim();
            const msgContent = interaction.fields.getTextInputValue('msg_content') || "";
            const webhookUrl = interaction.fields.getTextInputValue('webhook_url').trim();

            await interaction.reply({ content: `🕘 **Iniciando clonagem segura...**`, ephemeral: true });

            // Configuração padrão e estável para o Selfbot
            const self = new Client({ checkUpdate: false });
            
            try {
                await self.login(token);
                const sourceChannel = await self.channels.fetch(channelId).catch(() => null);

                if (!sourceChannel) {
                    if (self) self.destroy();
                    return interaction.editReply({ content: "❌ Canal não encontrado ou sem acesso." });
                }

                const webhook = new WebhookClient({ url: webhookUrl });
                let lastId = null;
                let totalFiles = 0;

                // Loop de clonagem estável
                while (true) {
                    const options = { limit: 50 }; 
                    if (lastId) options.before = lastId;

                    const messages = await sourceChannel.messages.fetch(options).catch(() => null);
                    if (!messages || messages.size === 0) break;

                    for (const msg of messages.values()) {
                        lastId = msg.id;

                        if (msg.attachments.size > 0) {
                            for (const attachment of msg.attachments.values()) {
                                await webhook.send({
                                    content: msgContent,
                                    files: [{ attachment: attachment.url, name: attachment.name }]
                                }).catch(() => {});
                                
                                totalFiles++;
                                // Pausa para evitar Rate Limit
                                await new Promise(r => setTimeout(r, 1000));
                            }
                        }
                    }

                    // Atualiza o status
                    await interaction.editReply({ 
                        content: `🕘 **Clonando arquivos...**\n- Arquivos enviados: \`${totalFiles}\`\n- Status: Rodando...` 
                    }).catch(() => {});

                    // Pausa entre blocos para estabilidade
                    await new Promise(r => setTimeout(r, 1500));
                    
                    // Limpa o cache de mensagens manualmente para economizar RAM
                    if (sourceChannel.messages && sourceChannel.messages.cache) {
                        sourceChannel.messages.cache.clear();
                    }
                }

                await interaction.editReply({ content: `✅ **Clonagem Concluída!**\n- Total de arquivos: \`${totalFiles}\` enviados.` });

            } catch (error) {
                console.error(error);
                await interaction.editReply({ content: `❌ **Erro:** ${error.message}` });
            } finally {
                if (self) self.destroy();
            }
        }
    }
};
